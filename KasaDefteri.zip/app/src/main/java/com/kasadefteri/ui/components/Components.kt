package com.kasadefteri.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kasadefteri.domain.model.Transaction
import com.kasadefteri.domain.model.TransactionType
import com.kasadefteri.ui.theme.*
import java.time.format.DateTimeFormatter

// ─── Tutar Formatlama ─────────────────────────────────────

fun Double.toTutar(): String {
    return String.format("%,.2f", this).replace(",", ".").let {
        val parts = it.split(".")
        "${parts[0].replace(".", ".")} ₺"
    }.also {
        return "₺ ${String.format("%,.0f", this)}"
    }
}

fun formatAmount(amount: Double): String = "₺ ${"%,.0f".format(amount).replace(",", ".")}"

// ─── Transaction Card ─────────────────────────────────────

@Composable
fun TransactionItem(
    transaction: Transaction,
    onClick: () -> Unit = {}
) {
    val isIncome = transaction.type == TransactionType.INCOME
    val bgColor = if (isIncome) incomeBgColor() else expenseBgColor()
    val amountColor = if (isIncome) incomeColor() else expenseColor()
    val sign = if (isIncome) "+" else "-"

    ListItem(
        headlineContent = {
            Text(
                text = transaction.description,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        supportingContent = {
            Text(
                text = "${transaction.category.label} · ${transaction.paymentMethod.label}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                Text(transaction.category.emoji, fontSize = 22.sp)
            }
        },
        trailingContent = {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$sign${formatAmount(transaction.amount)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = amountColor
                )
                Text(
                    text = transaction.time.format(DateTimeFormatter.ofPattern("HH:mm")),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        modifier = Modifier.clickable { onClick() }
    )
}

// ─── Balance Card ─────────────────────────────────────────

@Composable
fun BalanceCard(
    balance: Double,
    monthlyIncome: Double,
    monthlyExpense: Double,
    modifier: Modifier = Modifier
) {
    val isPositive = balance >= 0

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onBackground),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "GÜNCEL BAKİYE",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.6f),
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "${if (isPositive) "+" else ""}${formatAmount(balance)}",
                style = MaterialTheme.typography.headlineLarge,
                color = if (isPositive) KasaColors.IncomeDark else KasaColors.ExpenseDark
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniStatCard(
                    label = "Bu Ay Gelir",
                    value = formatAmount(monthlyIncome),
                    color = KasaColors.IncomeDark,
                    modifier = Modifier.weight(1f)
                )
                MiniStatCard(
                    label = "Bu Ay Gider",
                    value = formatAmount(monthlyExpense),
                    color = KasaColors.ExpenseDark,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun MiniStatCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

// ─── Budget Progress Bar ──────────────────────────────────

@Composable
fun BudgetProgressItem(
    categoryEmoji: String,
    categoryLabel: String,
    spent: Double,
    limit: Double,
    modifier: Modifier = Modifier
) {
    val percentage = if (limit > 0) (spent / limit).toFloat().coerceIn(0f, 1f) else 0f
    val progressColor = when {
        percentage >= 1f -> KasaColors.ExpenseMid
        percentage >= 0.8f -> KasaColors.Warning
        else -> KasaColors.IncomeMid
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$categoryEmoji $categoryLabel",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "${formatAmount(spent)} / ${formatAmount(limit)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { percentage },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = progressColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

// ─── Kasa Summary Row ─────────────────────────────────────

@Composable
fun KasaMiniStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
        }
    }
}

// ─── Section Header ───────────────────────────────────────

@Composable
fun SectionHeader(
    title: String,
    actionLabel: String? = null,
    onAction: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 0.5.sp
        )
        if (actionLabel != null) {
            TextButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 4.dp)) {
                Text(actionLabel, style = MaterialTheme.typography.bodySmall, color = KasaColors.Accent)
            }
        }
    }
}

// ─── Quick Action Buttons ─────────────────────────────────

@Composable
fun QuickActionButton(
    label: String,
    emoji: String,
    containerColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor),
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

// ─── Date Group Label ─────────────────────────────────────

@Composable
fun DateGroupHeader(dateLabel: String, totalIncome: Double, totalExpense: Double) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(dateLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (totalIncome > 0) Text(
                "+${formatAmount(totalIncome)}",
                style = MaterialTheme.typography.labelSmall,
                color = KasaColors.Income,
                fontWeight = FontWeight.Bold
            )
            if (totalExpense > 0) Text(
                "-${formatAmount(totalExpense)}",
                style = MaterialTheme.typography.labelSmall,
                color = KasaColors.Expense,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ─── Category Bar Chart Item ──────────────────────────────

@Composable
fun CategoryBarItem(
    emoji: String,
    label: String,
    amount: Double,
    maxAmount: Double,
    color: Color,
    modifier: Modifier = Modifier
) {
    val percentage = if (maxAmount > 0) (amount / maxAmount).toFloat() else 0f

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(emoji, fontSize = 18.sp, modifier = Modifier.width(28.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text(formatAmount(amount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { percentage },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = color,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
