package com.kasadefteri.ui.screens.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kasadefteri.domain.model.RecurringPayment
import com.kasadefteri.ui.components.*
import com.kasadefteri.ui.theme.KasaColors
import java.time.Month
import java.util.Locale

private val TAB_LABELS = listOf("Aylık", "Kategori", "Sabit Giderler")

val CATEGORY_COLORS = listOf(
    Color(0xFF2D9A6B), Color(0xFF378ADD), Color(0xFF7F77DD),
    Color(0xFFBA7517), Color(0xFFD4522F), Color(0xFF5DCAA5),
    Color(0xFFF0997B), Color(0xFF9F77E0), Color(0xFF4A9BBF), Color(0xFFE07A5F)
)

@Composable
fun ReportScreen(
    navController: NavController,
    viewModel: ReportViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {

        // ── Top Bar ──────────────────────────────────────
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📈 Raporlar", style = MaterialTheme.typography.headlineSmall)
            }
        }

        // ── Ay Navigasyon ────────────────────────────────
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.previousMonth() }) {
                        Icon(Icons.Default.ChevronLeft, null)
                    }
                    val monthName = Month.of(uiState.month).getDisplayName(
                        java.time.format.TextStyle.FULL, Locale("tr")
                    ).replaceFirstChar { it.uppercase() }
                    Text(
                        "$monthName ${uiState.year}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    IconButton(onClick = { viewModel.nextMonth() }) {
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }

        // ── Tab Row ──────────────────────────────────────
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = Color.Transparent,
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                TAB_LABELS.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(label, style = MaterialTheme.typography.bodyMedium) }
                    )
                }
            }
        }

        // ── Tab Content ───────────────────────────────────
        when (selectedTab) {

            // ── AYLIK ────────────────────────────────────
            0 -> {
                item {
                    // Özet kartları
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryStatCard("Toplam Gelir", formatAmount(uiState.totalIncome),
                            KasaColors.Income, Modifier.weight(1f))
                        SummaryStatCard("Toplam Gider", formatAmount(uiState.totalExpense),
                            KasaColors.Expense, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryStatCard("Net Tasarruf", formatAmount(uiState.netBalance),
                            KasaColors.Accent, Modifier.weight(1f))
                        SummaryStatCard("Tasarruf Oranı", "%${uiState.savingsRate}",
                            Color(0xFF378ADD), Modifier.weight(1f))
                    }
                }

                // Özet görseli
                item {
                    Spacer(Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Gelir vs Gider", style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(16.dp))

                            val maxVal = maxOf(uiState.totalIncome, uiState.totalExpense, 1.0)
                            IncomeExpenseBar("Gelir", uiState.totalIncome, maxVal, KasaColors.IncomeMid)
                            Spacer(Modifier.height(12.dp))
                            IncomeExpenseBar("Gider", uiState.totalExpense, maxVal, KasaColors.ExpenseMid)
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Aylık net", style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "${if (uiState.netBalance >= 0) "+" else ""}${formatAmount(uiState.netBalance)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (uiState.netBalance >= 0) KasaColors.Income else KasaColors.Expense
                                )
                            }
                        }
                    }
                }
            }

            // ── KATEGORİ ─────────────────────────────────
            1 -> {
                if (uiState.categoryStats.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(60.dp), Alignment.Center) {
                            Text("Bu ay harcama kaydı yok.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    item {
                        SectionHeader(title = "KATEGORİ BAZLI HARCAMA")
                    }
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                uiState.categoryStats.forEachIndexed { index, stat ->
                                    CategoryBarItem(
                                        emoji = stat.category.emoji,
                                        label = stat.category.label,
                                        amount = stat.amount,
                                        maxAmount = uiState.categoryStats.firstOrNull()?.amount ?: 1.0,
                                        color = CATEGORY_COLORS.getOrElse(index) { CATEGORY_COLORS[0] }
                                    )
                                }
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(12.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = KasaColors.AccentBg)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Toplam Gider", style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatAmount(uiState.totalExpense),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = KasaColors.Accent)
                            }
                        }
                    }
                }
            }

            // ── SABİT GİDERLER ────────────────────────────
            2 -> {
                item { SectionHeader(title = "SABİT GİDERLER") }

                items(uiState.recurringPayments) { rec ->
                    RecurringItem(
                        payment = rec,
                        onTogglePaid = { viewModel.markPaid(rec.id, !rec.isPaid) }
                    )
                }

                item {
                    Spacer(Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = KasaColors.AccentBg)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Toplam Sabit Gider", style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                formatAmount(uiState.recurringPayments.sumOf { it.amount }),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = KasaColors.Accent
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryStatCard(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
private fun IncomeExpenseBar(label: String, amount: Double, maxAmount: Double, color: Color) {
    val pct = if (maxAmount > 0) (amount / maxAmount).toFloat() else 0f
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(formatAmount(amount), style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { pct },
            modifier = Modifier.fillMaxWidth().height(10.dp).then(
                Modifier.wrapContentWidth()
            ),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
private fun RecurringItem(payment: RecurringPayment, onTogglePaid: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(payment.category.emoji, fontSize = 28.sp)
                Column {
                    Text(payment.name, style = MaterialTheme.typography.titleMedium)
                    Text("Ayın ${payment.dueDay}. günü · ${payment.paymentMethod.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(formatAmount(payment.amount), style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                val paidColor = if (payment.isPaid) KasaColors.Income else KasaColors.Expense
                val paidBg   = if (payment.isPaid) KasaColors.IncomeBg else KasaColors.ExpenseBg
                Surface(
                    onClick = onTogglePaid,
                    shape = RoundedCornerShape(8.dp),
                    color = paidBg
                ) {
                    Text(
                        if (payment.isPaid) "✓ Ödendi" else "Bekliyor",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = paidColor
                    )
                }
            }
        }
    }
}
