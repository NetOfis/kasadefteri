package com.kasadefteri.ui.screens.settings

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kasadefteri.ui.theme.KasaColors

@Composable
fun SettingsScreen() {
    var darkMode by remember { mutableStateOf(false) }
    var budgetAlerts by remember { mutableStateOf(true) }
    var dailySummary by remember { mutableStateOf(true) }
    var paymentReminders by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            // App Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = KasaColors.AccentBg)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            modifier = Modifier.size(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = KasaColors.Accent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🏠", style = MaterialTheme.typography.headlineSmall)
                            }
                        }
                        Column {
                            Text("KasaDefteri", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold)
                            Text("MVP v1.0 · Türkçe",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        item { SettingsSectionHeader("GÖRÜNÜM") }

        item {
            SettingsCard {
                SettingsToggleRow(
                    icon = Icons.Default.DarkMode,
                    iconBg = Color(0xFF272420),
                    iconTint = Color(0xFFE8D5A0),
                    title = "Koyu Tema",
                    subtitle = "Gözleri yormayan karanlık mod",
                    checked = darkMode,
                    onCheckedChange = { darkMode = it }
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsArrowRow(
                    icon = Icons.Default.Language,
                    iconBg = Color(0xFF0E1E35),
                    iconTint = Color(0xFF85B7EB),
                    title = "Para Birimi",
                    value = "₺ TRY"
                )
            }
        }

        item { SettingsSectionHeader("BİLDİRİMLER") }

        item {
            SettingsCard {
                SettingsToggleRow(
                    icon = Icons.Default.NotificationsActive,
                    iconBg = Color(0xFFFBF0E0),
                    iconTint = KasaColors.Accent,
                    title = "Ödeme Hatırlatmaları",
                    subtitle = "Sabit gider ödeme uyarıları",
                    checked = paymentReminders,
                    onCheckedChange = { paymentReminders = it }
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsToggleRow(
                    icon = Icons.Default.Summarize,
                    iconBg = Color(0xFFE8F5EE),
                    iconTint = KasaColors.Income,
                    title = "Gün Sonu Özeti",
                    subtitle = "Akşam günlük özet bildirimi",
                    checked = dailySummary,
                    onCheckedChange = { dailySummary = it }
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsToggleRow(
                    icon = Icons.Default.Warning,
                    iconBg = Color(0xFFFAEAE6),
                    iconTint = KasaColors.Expense,
                    title = "Bütçe Aşım Uyarısı",
                    subtitle = "Limit %80'e gelince bildir",
                    checked = budgetAlerts,
                    onCheckedChange = { budgetAlerts = it }
                )
            }
        }

        item { SettingsSectionHeader("VERİ") }

        item {
            SettingsCard {
                SettingsArrowRow(
                    icon = Icons.Default.TableChart,
                    iconBg = Color(0xFFE8F5EE),
                    iconTint = KasaColors.Income,
                    title = "Excel'e Aktar",
                    value = ""
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsArrowRow(
                    icon = Icons.Default.PictureAsPdf,
                    iconBg = Color(0xFFFAEAE6),
                    iconTint = KasaColors.Expense,
                    title = "PDF Rapor Al",
                    value = ""
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsArrowRow(
                    icon = Icons.Default.CloudUpload,
                    iconBg = Color(0xFFE8F0FB),
                    iconTint = Color(0xFF378ADD),
                    title = "Bulut Yedekleme",
                    value = "Hiç yapılmadı"
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsArrowRow(
                    icon = Icons.Default.RestoreFromTrash,
                    iconBg = Color(0xFFF5F3EF),
                    iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                    title = "Yedekten Geri Yükle",
                    value = ""
                )
            }
        }

        item { SettingsSectionHeader("KATEGORİLER") }

        item {
            SettingsCard {
                SettingsArrowRow(
                    icon = Icons.Default.Label,
                    iconBg = Color(0xFFF0EDE8),
                    iconTint = KasaColors.Accent,
                    title = "Kategorileri Düzenle",
                    value = "11 kategori"
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                SettingsArrowRow(
                    icon = Icons.Default.AddCircle,
                    iconBg = Color(0xFFF0EDE8),
                    iconTint = KasaColors.Accent,
                    title = "Yeni Kategori Ekle",
                    value = ""
                )
            }
        }

        item { SettingsSectionHeader("BÜTÇE") }

        item {
            SettingsCard {
                SettingsArrowRow(
                    icon = Icons.Default.AccountBalance,
                    iconBg = Color(0xFFE1F5EE),
                    iconTint = KasaColors.IncomeMid,
                    title = "Aylık Bütçe Limitleri",
                    value = "5 kategori"
                )
            }
        }

        item {
            Spacer(Modifier.height(16.dp))
            Text(
                "KasaDefteri · MVP v1.0\nTürkiye için geliştirildi",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 6.dp),
        letterSpacing = androidx.compose.ui.unit.TextUnit(0.8f, androidx.compose.ui.unit.TextUnitType.Sp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text(title, style = MaterialTheme.typography.titleMedium) },
        supportingContent = {
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        leadingContent = {
            Surface(shape = RoundedCornerShape(10.dp), color = iconBg, modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
            }
        },
        trailingContent = {
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White,
                    checkedTrackColor = KasaColors.Income)
            )
        }
    )
}

@Composable
private fun SettingsArrowRow(
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String,
    value: String
) {
    ListItem(
        headlineContent = { Text(title, style = MaterialTheme.typography.titleMedium) },
        leadingContent = {
            Surface(shape = RoundedCornerShape(10.dp), color = iconBg, modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
            }
        },
        trailingContent = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (value.isNotEmpty()) {
                    Text(value, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}
