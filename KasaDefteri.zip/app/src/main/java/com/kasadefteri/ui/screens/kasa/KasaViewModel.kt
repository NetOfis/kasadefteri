package com.kasadefteri.ui.screens.kasa

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasadefteri.data.repository.KasaRepository
import com.kasadefteri.domain.model.*
import com.kasadefteri.domain.usecase.AddTransactionUseCase
import com.kasadefteri.domain.model.DailySummary
import com.kasadefteri.domain.usecase.GetDailySummaryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class KasaUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val dailySummary: DailySummary? = null,
    val openingBalance: Double = 0.0,
    val isLoading: Boolean = true
)

@HiltViewModel
class KasaViewModel @Inject constructor(
    private val getDailySummary: GetDailySummaryUseCase,
    private val addTransaction: AddTransactionUseCase,
    private val repository: KasaRepository
) : ViewModel() {

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    private val _openingBalance = MutableStateFlow(0.0)

    val uiState: StateFlow<KasaUiState> = combine(
        _selectedDate,
        _selectedDate.flatMapLatest { date -> getDailySummary(date) },
        _openingBalance
    ) { date, summary, opening ->
        KasaUiState(
            selectedDate = date,
            dailySummary = summary,
            openingBalance = opening,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = KasaUiState()
    )

    private val _snackbar = MutableSharedFlow<String>()
    val snackbar: SharedFlow<String> = _snackbar.asSharedFlow()

    fun goToPreviousDay() { _selectedDate.value = _selectedDate.value.minusDays(1) }
    fun goToNextDay() {
        if (_selectedDate.value < LocalDate.now()) {
            _selectedDate.value = _selectedDate.value.plusDays(1)
        }
    }
    fun goToToday() { _selectedDate.value = LocalDate.now() }

    fun addTransaction(tx: Transaction) {
        viewModelScope.launch {
            addTransaction.invoke(tx.copy(date = _selectedDate.value))
            _snackbar.emit("✓ Kaydedildi")
        }
    }
}
