package com.kasadefteri.ui.screens.transactions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasadefteri.data.repository.KasaRepository
import com.kasadefteri.domain.model.*
import com.kasadefteri.domain.usecase.AddTransactionUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TransactionFilter(
    val searchQuery: String = "",
    val type: TransactionType? = null,
    val category: Category? = null
)

data class TransactionUiState(
    val transactions: List<Transaction> = emptyList(),
    val filter: TransactionFilter = TransactionFilter(),
    val isLoading: Boolean = true
)

@HiltViewModel
class TransactionViewModel @Inject constructor(
    private val repository: KasaRepository,
    private val addTransaction: AddTransactionUseCase
) : ViewModel() {

    private val _filter = MutableStateFlow(TransactionFilter())
    private val _snackbar = MutableSharedFlow<String>()
    val snackbar: SharedFlow<String> = _snackbar.asSharedFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<TransactionUiState> = _filter
        .flatMapLatest { filter ->
            val base = if (filter.searchQuery.isBlank()) repository.getAllTransactions()
            else repository.searchTransactions(filter.searchQuery)
            base.map { list ->
                list
                    .filter { tx -> filter.type == null || tx.type == filter.type }
                    .filter { tx -> filter.category == null || tx.category == filter.category }
            }.map { filtered ->
                TransactionUiState(filtered, filter, false)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TransactionUiState())

    fun setSearchQuery(q: String) { _filter.value = _filter.value.copy(searchQuery = q) }
    fun setTypeFilter(type: TransactionType?) { _filter.value = _filter.value.copy(type = type) }
    fun setCategoryFilter(cat: Category?) { _filter.value = _filter.value.copy(category = cat) }
    fun clearFilters() { _filter.value = TransactionFilter() }

    fun addTransaction(tx: Transaction) {
        viewModelScope.launch {
            addTransaction.invoke(tx)
            _snackbar.emit("✓ Kaydedildi")
        }
    }

    fun deleteTransaction(tx: Transaction) {
        viewModelScope.launch {
            repository.deleteTransaction(tx)
            _snackbar.emit("Silindi")
        }
    }
}
