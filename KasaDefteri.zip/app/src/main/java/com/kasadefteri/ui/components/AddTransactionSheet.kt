package com.kasadefteri.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kasadefteri.domain.model.*
import com.kasadefteri.ui.theme.*
import java.time.LocalDate
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionSheet(
    initialType: TransactionType = TransactionType.EXPENSE,
    onDismiss: () -> Unit,
    onSave: (Transaction) -> Unit
) {
    var type by remember { mutableStateOf(initialType) }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(Category.MARKET) }
    var selectedPayment by remember { mutableStateOf(PaymentMethod.CASH) }
    var isRecurring by remember { mutableStateOf(false) }

    val categories = if (type == TransactionType.INCOME) Category.incomeCategories()
    else Category.expenseCategories()

    val incColor = incomeColor()
    val expColor = expenseColor()
    val incBg = incomeBgColor()
    val expBg = expenseBgColor()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 8.dp)
    ) {
        // Handle
        Box(
            Modifier
                .width(36.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.outline)
                .align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(12.dp))

        // Başlık
        Text(
            text = if (type == TransactionType.INCOME) "Gelir Ekle" else "Gider Ekle",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        Spacer(Modifier.height(16.dp))

        // Tür Seçimi
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TypeToggleButton(
                label = "💸 Gider",
                selected = type == TransactionType.EXPENSE,
                selectedBg = expBg,
                selectedBorder = expColor,
                selectedText = expColor,
                onClick = {
                    type = TransactionType.EXPENSE
                    selectedCategory = Category.MARKET
                },
                modifier = Modifier.weight(1f)
            )
            TypeToggleButton(
                label = "💰 Gelir",
                selected = type == TransactionType.INCOME,
                selectedBg = incBg,
                selectedBorder = incColor,
                selectedText = incColor,
                onClick = {
                    type = TransactionType.INCOME
                    selectedCategory = Category.MAAS
                },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(16.dp))

        // Tutar
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text("TUTAR (₺)", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.5.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = amountText,
                onValueChange = { if (it.all { c -> c.isDigit() || c == '.' || c == ',' }) amountText = it },
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.headlineMedium.copy(
                    textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold
                ),
                placeholder = { Text("0", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                    style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.outline) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )
        }
        Spacer(Modifier.height(14.dp))

        // Açıklama
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text("AÇIKLAMA", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.5.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Harcama açıklaması...") },
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )
        }
        Spacer(Modifier.height(16.dp))

        // Kategori
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text("KATEGORİ", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.5.sp)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.heightIn(max = 300.dp),
                userScrollEnabled = false
            ) {
                items(categories) { cat ->
                    CategoryChip(
                        emoji = cat.emoji,
                        label = cat.label,
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat }
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        // Ödeme Yöntemi
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text("ÖDEME YÖNTEMİ", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.5.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PaymentMethod.entries.forEach { method ->
                    FilterChip(
                        selected = selectedPayment == method,
                        onClick = { selectedPayment = method },
                        label = { Text("${method.emoji} ${method.label}", style = MaterialTheme.typography.bodySmall) }
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // Sabit gider toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Sabit Gider", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text("Aylık tekrar eden ödeme", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = isRecurring, onCheckedChange = { isRecurring = it })
        }
        Spacer(Modifier.height(20.dp))

        // Kaydet Butonu
        val saveColor = if (type == TransactionType.INCOME) incColor else expColor
        Button(
            onClick = {
                val amount = amountText.replace(",", ".").toDoubleOrNull() ?: return@Button
                if (amount <= 0) return@Button
                val desc = description.ifBlank { selectedCategory.label }
                onSave(
                    Transaction(
                        type = type,
                        category = selectedCategory,
                        description = desc,
                        amount = amount,
                        date = LocalDate.now(),
                        time = LocalTime.now(),
                        paymentMethod = selectedPayment,
                        isRecurring = isRecurring
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = saveColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = if (type == TransactionType.INCOME) "💰 Geliri Kaydet" else "💸 Gideri Kaydet",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TypeToggleButton(
    label: String,
    selected: Boolean,
    selectedBg: Color,
    selectedBorder: Color,
    selectedText: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) selectedBg else MaterialTheme.colorScheme.surfaceVariant
    val border = if (selected) selectedBorder else MaterialTheme.colorScheme.outline
    val textColor = if (selected) selectedText else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(2.dp, border, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, color = textColor)
    }
}

@Composable
private fun CategoryChip(
    emoji: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected) KasaColors.AccentBg else MaterialTheme.colorScheme.surfaceVariant
    val border = if (selected) KasaColors.Accent else Color.Transparent
    val textColor = if (selected) KasaColors.Accent else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.5.dp, border, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 22.sp)
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            textAlign = TextAlign.Center,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
