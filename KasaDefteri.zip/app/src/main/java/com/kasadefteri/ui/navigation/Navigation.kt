package com.kasadefteri.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.kasadefteri.ui.screens.home.HomeScreen
import com.kasadefteri.ui.screens.kasa.KasaScreen
import com.kasadefteri.ui.screens.reports.ReportScreen
import com.kasadefteri.ui.screens.settings.SettingsScreen
import com.kasadefteri.ui.screens.transactions.TransactionScreen

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home         : Screen("home",         "Ana Sayfa",  Icons.Filled.Home)
    object Kasa         : Screen("kasa",         "Kasa",       Icons.Filled.Book)
    object Transactions : Screen("transactions", "İşlemler",   Icons.Filled.List)
    object Reports      : Screen("reports",      "Raporlar",   Icons.Filled.BarChart)
    object Settings     : Screen("settings",     "Ayarlar",    Icons.Filled.Settings)
}

val bottomNavItems = listOf(
    Screen.Home, Screen.Kasa, Screen.Transactions, Screen.Reports, Screen.Settings
)

@Composable
fun KasaNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar(tonalElevation = 0.dp) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                bottomNavItems.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label, style = MaterialTheme.typography.labelSmall) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = { fadeIn() },
            exitTransition = { fadeOut() }
        ) {
            composable(Screen.Home.route)         { HomeScreen(navController) }
            composable(Screen.Kasa.route)         { KasaScreen(navController) }
            composable(Screen.Transactions.route) { TransactionScreen(navController) }
            composable(Screen.Reports.route)      { ReportScreen(navController) }
            composable(Screen.Settings.route)     { SettingsScreen() }
        }
    }
}
