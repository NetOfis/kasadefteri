package com.kasadefteri.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasadefteri.data.repository.KasaRepository
import com.kasadefteri.domain.model.*
import com.kasadefteri.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import javax.inject.Inject

data class HomeUiState(
    val monthlyIncome: Double = 0.0,
    val monthlyExpense: Double = 0.0,
    val netBalance: Double = 0.0,
    val recentTransactions: List<Transaction> = emptyList(),
    val unpaidRecurring: List<RecurringPayment> = emptyList(),
    val budgetProgress: List<BudgetProgress> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: KasaRepository,
    private val addTransactionUseCase: AddTransactionUseCase,
    private val quickAddUseCase: QuickAddTransactionUseCase,
    private val budgetProgressUseCase: GetBudgetProgressUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    private val now = LocalDate.now()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            combine(
                repository.getTransactionsByMonth(now.monthValue, now.year),
                repository.getUnpaidRecurring(),
                repository.getBudgetsForMonth(now.monthValue, now.year)
            ) { transactions, unpaid, budgets ->
                val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

                val progress = budgets.map { budget ->
                    val spent = transactions
                        .filter { it.type == TransactionType.EXPENSE && it.category == budget.category }
                        .sumOf { it.amount }
                    val pct = if (budget.limitAmount > 0) (spent / budget.limitAmount).toFloat() else 0f
                    BudgetProgress(budget, spent, pct.coerceIn(0f, 2f))
                }

                HomeUiState(
                    monthlyIncome = income,
                    monthlyExpense = expense,
                    netBalance = income - expense,
                    recentTransactions = transactions.take(8),
                    unpaidRecurring = unpaid,
                    budgetProgress = progress,
                    isLoading = false
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun quickAdd(input: String) {
        viewModelScope.launch {
            val success = quickAddUseCase(input)
            _snackbarMessage.emit(if (success) "✓ Kaydedildi" else "⚠️ Geçersiz format. Örn: 250 market")
        }
    }

    fun addTransaction(transaction: Transaction) {
        viewModelScope.launch {
            addTransactionUseCase(transaction)
            _snackbarMessage.emit("✓ ${if (transaction.type == TransactionType.INCOME) "Gelir" else "Gider"} eklendi")
        }
    }

    fun markRecurringPaid(id: Long) {
        viewModelScope.launch {
            repository.markRecurringPaid(id, true)
            _snackbarMessage.emit("✓ Ödeme işaretlendi")
        }
    }
}
