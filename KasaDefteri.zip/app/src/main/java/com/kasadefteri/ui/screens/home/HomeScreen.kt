package com.kasadefteri.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kasadefteri.domain.model.TransactionType
import com.kasadefteri.ui.components.*
import com.kasadefteri.ui.theme.KasaColors
import com.kasadefteri.ui.navigation.Screen
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val keyboardController = LocalSoftwareKeyboardController.current

    var showAddSheet by remember { mutableStateOf(false) }
    var addSheetType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var fastInputText by remember { mutableStateOf("") }

    // Snackbar mesajlarını dinle
    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->

        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = KasaColors.Accent)
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {

            // ── Top Bar ──────────────────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "🏠 KasaDefteri",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE")),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Bildirimler",
                            tint = KasaColors.Accent)
                    }
                }
            }

            // ── Bakiye Kartı ─────────────────────────────
            item {
                BalanceCard(
                    balance = uiState.netBalance,
                    monthlyIncome = uiState.monthlyIncome,
                    monthlyExpense = uiState.monthlyExpense
                )
            }

            // ── Hızlı Kayıt Butonları ────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        label = "Gelir Ekle",
                        emoji = "+",
                        containerColor = KasaColors.Income,
                        onClick = {
                            addSheetType = TransactionType.INCOME
                            showAddSheet = true
                        },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionButton(
                        label = "Gider Ekle",
                        emoji = "-",
                        containerColor = KasaColors.Expense,
                        onClick = {
                            addSheetType = TransactionType.EXPENSE
                            showAddSheet = true
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ── Hızlı Metin Girişi ───────────────────────
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        OutlinedTextField(
                            value = fastInputText,
                            onValueChange = { fastInputText = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = {
                                Text("örn: 250 market  veya  2000 maaş",
                                    style = MaterialTheme.typography.bodyMedium)
                            },
                            trailingIcon = {
                                IconButton(onClick = {
                                    if (fastInputText.isNotBlank()) {
                                        viewModel.quickAdd(fastInputText.trim())
                                        fastInputText = ""
                                        keyboardController?.hide()
                                    }
                                }) {
                                    Icon(Icons.Default.Send, contentDescription = "Gönder",
                                        tint = KasaColors.Accent)
                                }
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (fastInputText.isNotBlank()) {
                                    viewModel.quickAdd(fastInputText.trim())
                                    fastInputText = ""
                                    keyboardController?.hide()
                                }
                            }),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        Text(
                            "💡 Tutar + kategori yazarak hızlıca kaydet",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp, start = 4.dp)
                        )
                    }
                }
            }

            // ── Yaklaşan Ödemeler ────────────────────────
            if (uiState.unpaidRecurring.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "⚡ YAKLAŞAN ÖDEMELER",
                        actionLabel = "Tümü",
                        onAction = { navController.navigate(Screen.Reports.route) }
                    )
                }
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        uiState.unpaidRecurring.take(3).forEach { recurring ->
                            val daysLeft = recurring.dueDay - LocalDate.now().dayOfMonth
                            val badgeColor = when {
                                daysLeft <= 0 -> KasaColors.Expense
                                daysLeft <= 2 -> KasaColors.Expense
                                daysLeft <= 5 -> KasaColors.Warning
                                else -> KasaColors.Income
                            }
                            val badgeText = when {
                                daysLeft < 0 -> "Gecikmiş!"
                                daysLeft == 0 -> "Bugün!"
                                else -> "$daysLeft gün"
                            }
                            ListItem(
                                headlineContent = { Text(recurring.name, style = MaterialTheme.typography.titleMedium) },
                                supportingContent = {
                                    Text("Ayın ${recurring.dueDay}. günü",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                },
                                leadingContent = {
                                    Text(recurring.category.emoji, fontSize = 28.sp)
                                },
                                trailingContent = {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            formatAmount(recurring.amount),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = badgeColor.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                badgeText,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = badgeColor
                                            )
                                        }
                                    }
                                }
                            )
                            if (recurring != uiState.unpaidRecurring.take(3).last()) {
                                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }

            // ── Bütçe Takibi ─────────────────────────────
            if (uiState.budgetProgress.isNotEmpty()) {
                item {
                    SectionHeader(title = "📊 BÜTÇE KULLANIMI")
                }
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            uiState.budgetProgress.forEach { progress ->
                                BudgetProgressItem(
                                    categoryEmoji = progress.budget.category.emoji,
                                    categoryLabel = progress.budget.category.label,
                                    spent = progress.spent,
                                    limit = progress.budget.limitAmount
                                )
                            }
                        }
                    }
                }
            }

            // ── Son İşlemler ─────────────────────────────
            item {
                SectionHeader(
                    title = "🕐 SON İŞLEMLER",
                    actionLabel = "Tümü",
                    onAction = { navController.navigate(Screen.Transactions.route) }
                )
            }

            if (uiState.recentTransactions.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("📒", fontSize = 40.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Henüz işlem yok.\nGelir veya gider ekleyin.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column {
                            uiState.recentTransactions.forEachIndexed { index, transaction ->
                                TransactionItem(transaction = transaction)
                                if (index < uiState.recentTransactions.lastIndex) {
                                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ── AddTransaction Bottom Sheet ───────────────────────
    if (showAddSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            AddTransactionSheet(
                initialType = addSheetType,
                onDismiss = { showAddSheet = false },
                onSave = { transaction ->
                    viewModel.addTransaction(transaction)
                    showAddSheet = false
                }
            )
        }
    }
}
