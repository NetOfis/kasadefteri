package com.kasadefteri.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasadefteri.data.repository.KasaRepository
import com.kasadefteri.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class CategoryStat(
    val category: Category,
    val amount: Double,
    val percentage: Float
)

data class ReportUiState(
    val month: Int = LocalDate.now().monthValue,
    val year: Int = LocalDate.now().year,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val categoryStats: List<CategoryStat> = emptyList(),
    val recurringPayments: List<RecurringPayment> = emptyList(),
    val isLoading: Boolean = true
) {
    val netBalance get() = totalIncome - totalExpense
    val savingsRate get() = if (totalIncome > 0) (netBalance / totalIncome * 100).toInt() else 0
}

@HiltViewModel
class ReportViewModel @Inject constructor(
    private val repository: KasaRepository
) : ViewModel() {

    private val _month = MutableStateFlow(LocalDate.now().monthValue)
    private val _year  = MutableStateFlow(LocalDate.now().year)

    val uiState: StateFlow<ReportUiState> = combine(
        _month, _year
    ) { month, year -> month to year }
        .flatMapLatest { (month, year) ->
            combine(
                repository.getTransactionsByMonth(month, year),
                repository.getAllRecurring()
            ) { transactions, recurring ->
                val income  = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

                val catMap = transactions
                    .filter { it.type == TransactionType.EXPENSE }
                    .groupBy { it.category }
                    .mapValues { (_, list) -> list.sumOf { it.amount } }

                val stats = catMap.entries
                    .sortedByDescending { it.value }
                    .map { (cat, amt) ->
                        CategoryStat(cat, amt, if (expense > 0) (amt / expense).toFloat() else 0f)
                    }

                ReportUiState(month, year, income, expense, stats, recurring, false)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReportUiState())

    fun previousMonth() {
        if (_month.value == 1) { _month.value = 12; _year.value-- }
        else _month.value--
    }
    fun nextMonth() {
        val now = LocalDate.now()
        if (_year.value < now.year || (_year.value == now.year && _month.value < now.monthValue)) {
            if (_month.value == 12) { _month.value = 1; _year.value++ }
            else _month.value++
        }
    }

    fun markPaid(id: Long, paid: Boolean) {
        viewModelScope.launch { repository.markRecurringPaid(id, paid) }
    }
}
