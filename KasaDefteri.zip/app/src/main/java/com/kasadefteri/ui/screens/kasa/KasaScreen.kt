package com.kasadefteri.ui.screens.kasa

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kasadefteri.domain.model.TransactionType
import com.kasadefteri.ui.components.*
import com.kasadefteri.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasaScreen(
    navController: NavController,
    viewModel: KasaViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddSheet by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf(TransactionType.EXPENSE) }

    LaunchedEffect(Unit) {
        viewModel.snackbar.collect { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { addType = TransactionType.EXPENSE; showAddSheet = true },
                containerColor = KasaColors.Expense
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ekle", tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    ) { padding ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {

            // ── Top Bar ──────────────────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📒 Kasa Defteri", style = MaterialTheme.typography.headlineSmall)
                    TextButton(onClick = { viewModel.goToToday() }) {
                        Text("Bugün", color = KasaColors.Accent)
                    }
                }
            }

            // ── Tarih Navigasyon ─────────────────────────
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.goToPreviousDay() }) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Önceki gün",
                                modifier = Modifier.size(28.dp))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = uiState.selectedDate.format(
                                    DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("tr"))
                                ),
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = uiState.selectedDate.format(
                                    DateTimeFormatter.ofPattern("EEEE", Locale("tr"))
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { viewModel.goToNextDay() },
                            enabled = uiState.selectedDate < LocalDate.now()
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Sonraki gün",
                                modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }

            // ── Günlük Özet ──────────────────────────────
            item {
                val summary = uiState.dailySummary
                val inc = summary?.totalIncome ?: 0.0
                val exp = summary?.totalExpense ?: 0.0
                val net = uiState.openingBalance + inc - exp

                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KasaMiniStat(
                        label = "AÇILIŞ",
                        value = formatAmount(uiState.openingBalance),
                        color = KasaColors.Accent,
                        modifier = Modifier.weight(1f)
                    )
                    KasaMiniStat(
                        label = "GELİR",
                        value = formatAmount(inc),
                        color = KasaColors.Income,
                        modifier = Modifier.weight(1f)
                    )
                    KasaMiniStat(
                        label = "GİDER",
                        value = formatAmount(exp),
                        color = KasaColors.Expense,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (net >= 0) KasaColors.IncomeBg else KasaColors.ExpenseBg
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Gün Sonu Bakiye",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            formatAmount(net),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (net >= 0) KasaColors.Income else KasaColors.Expense
                        )
                    }
                }
            }

            // ── Hızlı Ekle Butonları ──────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { addType = TransactionType.INCOME; showAddSheet = true },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, null, tint = KasaColors.Income, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Gelir Ekle", color = KasaColors.Income, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { addType = TransactionType.EXPENSE; showAddSheet = true },
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KasaColors.Expense),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Remove, null, tint = androidx.compose.ui.graphics.Color.White,
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Gider Ekle", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ── Gün Hareketleri ──────────────────────────
            item {
                SectionHeader(title = "GÜN İÇİ HAREKETLER")
            }

            val transactions = uiState.dailySummary?.transactions ?: emptyList()
            if (transactions.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("📒", fontSize = 40.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("Bu gün için hareket yok.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column {
                            transactions
                                .sortedBy { it.time }
                                .forEachIndexed { index, tx ->
                                    TransactionItem(transaction = tx)
                                    if (index < transactions.lastIndex) {
                                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                                    }
                                }
                        }
                    }
                }
            }
        }
    }

    // Bottom Sheet
    if (showAddSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            AddTransactionSheet(
                initialType = addType,
                onDismiss = { showAddSheet = false },
                onSave = { tx ->
                    viewModel.addTransaction(tx)
                    showAddSheet = false
                }
            )
        }
    }
}
