package com.kasadefteri.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ─── Renkler ─────────────────────────────────────────────

object KasaColors {
    // Gelir
    val Income         = Color(0xFF1A6B4A)
    val IncomeDark     = Color(0xFF6EDBA8)
    val IncomeBg       = Color(0xFFE8F5EE)
    val IncomeBgDark   = Color(0xFF0D2E1E)
    val IncomeMid      = Color(0xFF2D9A6B)

    // Gider
    val Expense        = Color(0xFFB83A20)
    val ExpenseDark    = Color(0xFFF08070)
    val ExpenseBg      = Color(0xFFFAEAE6)
    val ExpenseBgDark  = Color(0xFF2A1510)
    val ExpenseMid     = Color(0xFFD4522F)

    // Vurgu
    val Accent         = Color(0xFFC17B2A)
    val AccentBg       = Color(0xFFFBF0E0)
    val AccentBgDark   = Color(0xFF2A1E08)

    // Nötr
    val Surface        = Color(0xFFFFFFFF)
    val SurfaceDark    = Color(0xFF1E1C18)
    val Background     = Color(0xFFF5F3EF)
    val BackgroundDark = Color(0xFF141210)
    val CardBg         = Color(0xFFFFFFFF)
    val CardBgDark     = Color(0xFF1E1C18)

    val OnSurface      = Color(0xFF1A1814)
    val OnSurfaceDark  = Color(0xFFF0EDE8)
    val OnSurfaceSub   = Color(0xFF6B6560)
    val OnSurfaceSubDark = Color(0xFF9A9590)

    val Border         = Color(0xFFE5E0DA)
    val BorderDark     = Color(0xFF2E2B26)

    val Warning        = Color(0xFFBA7517)
}

// ─── Material 3 Color Scheme ──────────────────────────────

private val LightColorScheme = lightColorScheme(
    primary          = KasaColors.Accent,
    onPrimary        = Color.White,
    primaryContainer = KasaColors.AccentBg,
    secondary        = KasaColors.Income,
    onSecondary      = Color.White,
    tertiary         = KasaColors.Expense,
    background       = KasaColors.Background,
    surface          = KasaColors.Surface,
    onBackground     = KasaColors.OnSurface,
    onSurface        = KasaColors.OnSurface,
    outline          = KasaColors.Border,
    surfaceVariant   = Color(0xFFF0EDE8),
    onSurfaceVariant = KasaColors.OnSurfaceSub
)

private val DarkColorScheme = darkColorScheme(
    primary          = KasaColors.Accent,
    onPrimary        = Color.White,
    primaryContainer = KasaColors.AccentBgDark,
    secondary        = KasaColors.IncomeDark,
    onSecondary      = Color.Black,
    tertiary         = KasaColors.ExpenseDark,
    background       = KasaColors.BackgroundDark,
    surface          = KasaColors.SurfaceDark,
    onBackground     = KasaColors.OnSurfaceDark,
    onSurface        = KasaColors.OnSurfaceDark,
    outline          = KasaColors.BorderDark,
    surfaceVariant   = Color(0xFF272420),
    onSurfaceVariant = KasaColors.OnSurfaceSubDark
)

// ─── Theme ────────────────────────────────────────────────

@Composable
fun KasaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(
            headlineLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 28.sp),
            headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp),
            headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp),
            titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp),
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp),
            bodyLarge = TextStyle(fontSize = 16.sp),
            bodyMedium = TextStyle(fontSize = 14.sp),
            bodySmall = TextStyle(fontSize = 12.sp),
            labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
        ),
        content = content
    )
}

// ─── Yardımcı Renkler ─────────────────────────────────────

@Composable
fun incomeColor(dark: Boolean = isSystemInDarkTheme()) =
    if (dark) KasaColors.IncomeDark else KasaColors.Income

@Composable
fun expenseColor(dark: Boolean = isSystemInDarkTheme()) =
    if (dark) KasaColors.ExpenseDark else KasaColors.Expense

@Composable
fun incomeBgColor(dark: Boolean = isSystemInDarkTheme()) =
    if (dark) KasaColors.IncomeBgDark else KasaColors.IncomeBg

@Composable
fun expenseBgColor(dark: Boolean = isSystemInDarkTheme()) =
    if (dark) KasaColors.ExpenseBgDark else KasaColors.ExpenseBg
