package com.kasadefteri.ui.screens.transactions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kasadefteri.domain.model.*
import com.kasadefteri.ui.components.*
import com.kasadefteri.ui.theme.KasaColors
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionScreen(
    navController: NavController,
    viewModel: TransactionViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddSheet by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var searchText by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf<TransactionType?>(null) }

    LaunchedEffect(Unit) {
        viewModel.snackbar.collect { snackbarHostState.showSnackbar(it) }
    }

    // Tarihe göre grupla
    val grouped = uiState.transactions.groupBy { it.date }.toSortedMap(compareByDescending { it })

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { addType = TransactionType.EXPENSE; showAddSheet = true },
                containerColor = KasaColors.Expense
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ekle",
                    tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {

            // ── Top Bar ──────────────────────────────────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("📋 İşlemler", style = MaterialTheme.typography.headlineSmall)
                        Text("${uiState.transactions.size} işlem",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // ── Arama ────────────────────────────────────
            item {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it; viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    placeholder = { Text("İşlem ara...") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (searchText.isNotEmpty()) {
                            IconButton(onClick = { searchText = ""; viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, null)
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }

            // ── Filtre Chipleri ───────────────────────────
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedTypeFilter == null,
                            onClick = { selectedTypeFilter = null; viewModel.setTypeFilter(null) },
                            label = { Text("Tümü") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTypeFilter == TransactionType.INCOME,
                            onClick = {
                                selectedTypeFilter = TransactionType.INCOME
                                viewModel.setTypeFilter(TransactionType.INCOME)
                            },
                            label = { Text("💰 Gelir") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTypeFilter == TransactionType.EXPENSE,
                            onClick = {
                                selectedTypeFilter = TransactionType.EXPENSE
                                viewModel.setTypeFilter(TransactionType.EXPENSE)
                            },
                            label = { Text("💸 Gider") }
                        )
                    }
                    items(Category.expenseCategories().take(5)) { cat ->
                        FilterChip(
                            selected = false,
                            onClick = { viewModel.setCategoryFilter(cat) },
                            label = { Text("${cat.emoji} ${cat.label}") }
                        )
                    }
                }
            }

            // ── Grouped List ──────────────────────────────
            if (grouped.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔍", fontSize = 40.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("Sonuç bulunamadı.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                grouped.forEach { (date, txList) ->
                    val dayIncome = txList.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                    val dayExpense = txList.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                    val dateLabel = date.format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", Locale("tr")))

                    item(key = date.toString()) {
                        DateGroupHeader(
                            dateLabel = dateLabel,
                            totalIncome = dayIncome,
                            totalExpense = dayExpense
                        )
                    }

                    item(key = "${date}_card") {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .padding(bottom = 8.dp),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column {
                                txList.sortedByDescending { it.time }.forEachIndexed { index, tx ->
                                    var showDeleteDialog by remember { mutableStateOf(false) }

                                    TransactionItem(
                                        transaction = tx,
                                        onClick = { showDeleteDialog = true }
                                    )
                                    if (index < txList.lastIndex) {
                                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                                    }

                                    if (showDeleteDialog) {
                                        AlertDialog(
                                            onDismissRequest = { showDeleteDialog = false },
                                            title = { Text("İşlemi sil") },
                                            text = { Text("\"${tx.description}\" silinsin mi?") },
                                            confirmButton = {
                                                TextButton(onClick = {
                                                    viewModel.deleteTransaction(tx)
                                                    showDeleteDialog = false
                                                }) { Text("Sil", color = KasaColors.Expense) }
                                            },
                                            dismissButton = {
                                                TextButton(onClick = { showDeleteDialog = false }) { Text("İptal") }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            AddTransactionSheet(
                initialType = addType,
                onDismiss = { showAddSheet = false },
                onSave = { tx ->
                    viewModel.addTransaction(tx)
                    showAddSheet = false
                }
            )
        }
    }
}
