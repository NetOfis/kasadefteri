package com.kasadefteri.data.local.dao

import androidx.room.*
import com.kasadefteri.data.local.entity.BudgetEntity
import com.kasadefteri.data.local.entity.RecurringPaymentEntity
import com.kasadefteri.data.local.entity.TransactionEntity
import com.kasadefteri.domain.model.Category
import com.kasadefteri.domain.model.TransactionType
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

// ─── Transaction DAO ─────────────────────────────────────

@Dao
interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Update
    suspend fun update(transaction: TransactionEntity)

    @Delete
    suspend fun delete(transaction: TransactionEntity)

    @Query("SELECT * FROM transactions ORDER BY date DESC, time DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE date = :date ORDER BY time DESC")
    fun getTransactionsByDate(date: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE strftime('%Y-%m', date) = :yearMonth ORDER BY date DESC, time DESC")
    fun getTransactionsByMonth(yearMonth: String): Flow<List<TransactionEntity>>

    @Query("""
        SELECT * FROM transactions 
        WHERE date BETWEEN :startDate AND :endDate 
        ORDER BY date DESC, time DESC
    """)
    fun getTransactionsByDateRange(startDate: String, endDate: String): Flow<List<TransactionEntity>>

    @Query("""
        SELECT * FROM transactions 
        WHERE (description LIKE '%' || :query || '%') 
        ORDER BY date DESC
    """)
    fun searchTransactions(query: String): Flow<List<TransactionEntity>>

    @Query("""
        SELECT SUM(amount) FROM transactions 
        WHERE type = :type AND strftime('%Y-%m', date) = :yearMonth
    """)
    suspend fun getTotalByTypeAndMonth(type: String, yearMonth: String): Double?

    @Query("""
        SELECT SUM(amount) FROM transactions 
        WHERE type = 'EXPENSE' AND category = :category AND strftime('%Y-%m', date) = :yearMonth
    """)
    suspend fun getCategorySpendForMonth(category: String, yearMonth: String): Double?

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: Long): TransactionEntity?

    @Query("""
        SELECT * FROM transactions 
        WHERE type = :type AND strftime('%Y-%m', date) = :yearMonth 
        ORDER BY amount DESC 
        LIMIT :limit
    """)
    suspend fun getTopByTypeAndMonth(type: String, yearMonth: String, limit: Int): List<TransactionEntity>
}

// ─── Recurring DAO ───────────────────────────────────────

@Dao
interface RecurringPaymentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payment: RecurringPaymentEntity): Long

    @Update
    suspend fun update(payment: RecurringPaymentEntity)

    @Delete
    suspend fun delete(payment: RecurringPaymentEntity)

    @Query("SELECT * FROM recurring_payments ORDER BY dueDay ASC")
    fun getAllRecurringPayments(): Flow<List<RecurringPaymentEntity>>

    @Query("SELECT * FROM recurring_payments WHERE isActive = 1 ORDER BY dueDay ASC")
    fun getActiveRecurringPayments(): Flow<List<RecurringPaymentEntity>>

    @Query("SELECT * FROM recurring_payments WHERE isPaid = 0 AND isActive = 1 ORDER BY dueDay ASC")
    fun getUnpaidRecurringPayments(): Flow<List<RecurringPaymentEntity>>

    @Query("UPDATE recurring_payments SET isPaid = :isPaid WHERE id = :id")
    suspend fun updatePaidStatus(id: Long, isPaid: Boolean)

    @Query("UPDATE recurring_payments SET isPaid = 0")
    suspend fun resetAllPaidStatus()
}

// ─── Budget DAO ───────────────────────────────────────────

@Dao
interface BudgetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(budget: BudgetEntity)

    @Update
    suspend fun update(budget: BudgetEntity)

    @Delete
    suspend fun delete(budget: BudgetEntity)

    @Query("SELECT * FROM budgets WHERE month = :month AND year = :year")
    fun getBudgetsForMonth(month: Int, year: Int): Flow<List<BudgetEntity>>

    @Query("SELECT * FROM budgets WHERE category = :category AND month = :month AND year = :year")
    suspend fun getBudgetForCategory(category: String, month: Int, year: Int): BudgetEntity?
}
