package com.kasadefteri.data.repository

import com.kasadefteri.data.local.dao.BudgetDao
import com.kasadefteri.data.local.dao.RecurringPaymentDao
import com.kasadefteri.data.local.dao.TransactionDao
import com.kasadefteri.data.local.entity.*
import com.kasadefteri.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class KasaRepository @Inject constructor(
    private val transactionDao: TransactionDao,
    private val recurringDao: RecurringPaymentDao,
    private val budgetDao: BudgetDao
) {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM")
    private val fullDateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    // ─── Transactions ────────────────────────────────────

    suspend fun addTransaction(transaction: Transaction): Long =
        transactionDao.insert(transaction.toEntity())

    suspend fun updateTransaction(transaction: Transaction) =
        transactionDao.update(transaction.toEntity())

    suspend fun deleteTransaction(transaction: Transaction) =
        transactionDao.delete(transaction.toEntity())

    fun getAllTransactions(): Flow<List<Transaction>> =
        transactionDao.getAllTransactions().map { list -> list.map { it.toDomain() } }

    fun getTransactionsByDate(date: LocalDate): Flow<List<Transaction>> =
        transactionDao.getTransactionsByDate(date.format(fullDateFormatter))
            .map { list -> list.map { it.toDomain() } }

    fun getTransactionsByMonth(month: Int, year: Int): Flow<List<Transaction>> {
        val yearMonth = "%04d-%02d".format(year, month)
        return transactionDao.getTransactionsByMonth(yearMonth)
            .map { list -> list.map { it.toDomain() } }
    }

    fun searchTransactions(query: String): Flow<List<Transaction>> =
        transactionDao.searchTransactions(query).map { list -> list.map { it.toDomain() } }

    suspend fun getMonthlyIncome(month: Int, year: Int): Double {
        val yearMonth = "%04d-%02d".format(year, month)
        return transactionDao.getTotalByTypeAndMonth("INCOME", yearMonth) ?: 0.0
    }

    suspend fun getMonthlyExpense(month: Int, year: Int): Double {
        val yearMonth = "%04d-%02d".format(year, month)
        return transactionDao.getTotalByTypeAndMonth("EXPENSE", yearMonth) ?: 0.0
    }

    suspend fun getCategorySpend(category: Category, month: Int, year: Int): Double {
        val yearMonth = "%04d-%02d".format(year, month)
        return transactionDao.getCategorySpendForMonth(category.name, yearMonth) ?: 0.0
    }

    // ─── Recurring Payments ───────────────────────────────

    suspend fun addRecurring(payment: RecurringPayment): Long =
        recurringDao.insert(payment.toEntity())

    suspend fun updateRecurring(payment: RecurringPayment) =
        recurringDao.update(payment.toEntity())

    suspend fun deleteRecurring(payment: RecurringPayment) =
        recurringDao.delete(payment.toEntity())

    fun getAllRecurring(): Flow<List<RecurringPayment>> =
        recurringDao.getAllRecurringPayments().map { list -> list.map { it.toDomain() } }

    fun getUnpaidRecurring(): Flow<List<RecurringPayment>> =
        recurringDao.getUnpaidRecurringPayments().map { list -> list.map { it.toDomain() } }

    suspend fun markRecurringPaid(id: Long, paid: Boolean) =
        recurringDao.updatePaidStatus(id, paid)

    // ─── Budgets ─────────────────────────────────────────

    suspend fun saveBudget(budget: Budget) = budgetDao.insert(budget.toEntity())

    fun getBudgetsForMonth(month: Int, year: Int): Flow<List<Budget>> =
        budgetDao.getBudgetsForMonth(month, year).map { list -> list.map { it.toDomain() } }

    // ─── Seed Data (İlk kurulum) ──────────────────────────

    suspend fun seedDefaultRecurring() {
        val defaults = listOf(
            RecurringPayment(name = "Ev Kirası",    category = Category.KIRA,    amount = 8000.0, dueDay = 2,  paymentMethod = PaymentMethod.TRANSFER),
            RecurringPayment(name = "Elektrik",     category = Category.FATURA,  amount = 450.0,  dueDay = 5,  paymentMethod = PaymentMethod.BANK),
            RecurringPayment(name = "Doğalgaz",     category = Category.FATURA,  amount = 380.0,  dueDay = 8,  paymentMethod = PaymentMethod.BANK),
            RecurringPayment(name = "Su Faturası",  category = Category.FATURA,  amount = 180.0,  dueDay = 10, paymentMethod = PaymentMethod.BANK),
            RecurringPayment(name = "İnternet",     category = Category.FATURA,  amount = 280.0,  dueDay = 15, paymentMethod = PaymentMethod.BANK),
            RecurringPayment(name = "Aidat",        category = Category.AIDAT,   amount = 500.0,  dueDay = 1,  paymentMethod = PaymentMethod.CASH),
        )
        defaults.forEach { recurringDao.insert(it.toEntity()) }
    }
}
