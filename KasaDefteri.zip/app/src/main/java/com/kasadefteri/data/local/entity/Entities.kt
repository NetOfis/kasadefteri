package com.kasadefteri.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.kasadefteri.domain.model.*
import java.time.LocalDate
import java.time.LocalTime

// ─── Type Converters ─────────────────────────────────────

class Converters {
    @TypeConverter fun fromLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }
    @TypeConverter fun toLocalDate(date: LocalDate?): String? = date?.toString()

    @TypeConverter fun fromLocalTime(value: String?): LocalTime? = value?.let { LocalTime.parse(it) }
    @TypeConverter fun toLocalTime(time: LocalTime?): String? = time?.toString()

    @TypeConverter fun fromTransactionType(value: String?): TransactionType? = value?.let { TransactionType.valueOf(it) }
    @TypeConverter fun toTransactionType(type: TransactionType?): String? = type?.name

    @TypeConverter fun fromCategory(value: String?): Category? = value?.let { Category.valueOf(it) }
    @TypeConverter fun toCategory(cat: Category?): String? = cat?.name

    @TypeConverter fun fromPaymentMethod(value: String?): PaymentMethod? = value?.let { PaymentMethod.valueOf(it) }
    @TypeConverter fun toPaymentMethod(method: PaymentMethod?): String? = method?.name

    @TypeConverter fun fromFrequency(value: String?): RecurringFrequency? = value?.let { RecurringFrequency.valueOf(it) }
    @TypeConverter fun toFrequency(freq: RecurringFrequency?): String? = freq?.name
}

// ─── Entities ─────────────────────────────────────────────

@Entity(tableName = "transactions")
@TypeConverters(Converters::class)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: TransactionType,
    val category: Category,
    val description: String,
    val amount: Double,
    val date: LocalDate,
    val time: LocalTime,
    val paymentMethod: PaymentMethod,
    val isRecurring: Boolean = false,
    val note: String? = null
)

@Entity(tableName = "recurring_payments")
@TypeConverters(Converters::class)
data class RecurringPaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: Category,
    val amount: Double,
    val dueDay: Int,
    val frequency: RecurringFrequency,
    val isActive: Boolean = true,
    val isPaid: Boolean = false,
    val paymentMethod: PaymentMethod
)

@Entity(tableName = "budgets", primaryKeys = ["category", "month", "year"])
@TypeConverters(Converters::class)
data class BudgetEntity(
    val id: Long = 0,
    val category: Category,
    val limitAmount: Double,
    val month: Int,
    val year: Int
)

// ─── Mappers ─────────────────────────────────────────────

fun TransactionEntity.toDomain() = com.kasadefteri.domain.model.Transaction(
    id, type, category, description, amount, date, time, paymentMethod, isRecurring, note
)

fun com.kasadefteri.domain.model.Transaction.toEntity() = TransactionEntity(
    id, type, category, description, amount, date, time, paymentMethod, isRecurring, note
)

fun RecurringPaymentEntity.toDomain() = com.kasadefteri.domain.model.RecurringPayment(
    id, name, category, amount, dueDay, frequency, isActive, isPaid, paymentMethod
)

fun com.kasadefteri.domain.model.RecurringPayment.toEntity() = RecurringPaymentEntity(
    id, name, category, amount, dueDay, frequency, isActive, isPaid, paymentMethod
)

fun BudgetEntity.toDomain() = com.kasadefteri.domain.model.Budget(
    id, category, limitAmount, month, year
)

fun com.kasadefteri.domain.model.Budget.toEntity() = BudgetEntity(
    id, category, limitAmount, month, year
)
