package com.kasadefteri.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.kasadefteri.data.local.dao.BudgetDao
import com.kasadefteri.data.local.dao.RecurringPaymentDao
import com.kasadefteri.data.local.dao.TransactionDao
import com.kasadefteri.data.local.entity.BudgetEntity
import com.kasadefteri.data.local.entity.Converters
import com.kasadefteri.data.local.entity.RecurringPaymentEntity
import com.kasadefteri.data.local.entity.TransactionEntity

@Database(
    entities = [
        TransactionEntity::class,
        RecurringPaymentEntity::class,
        BudgetEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class KasaDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun recurringPaymentDao(): RecurringPaymentDao
    abstract fun budgetDao(): BudgetDao
}
