package com.kasadefteri.di

import android.content.Context
import androidx.room.Room
import com.kasadefteri.data.local.dao.BudgetDao
import com.kasadefteri.data.local.dao.RecurringPaymentDao
import com.kasadefteri.data.local.dao.TransactionDao
import com.kasadefteri.data.local.database.KasaDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): KasaDatabase =
        Room.databaseBuilder(
            context,
            KasaDatabase::class.java,
            "kasa_database"
        ).build()

    @Provides
    fun provideTransactionDao(db: KasaDatabase): TransactionDao = db.transactionDao()

    @Provides
    fun provideRecurringDao(db: KasaDatabase): RecurringPaymentDao = db.recurringPaymentDao()

    @Provides
    fun provideBudgetDao(db: KasaDatabase): BudgetDao = db.budgetDao()
}
