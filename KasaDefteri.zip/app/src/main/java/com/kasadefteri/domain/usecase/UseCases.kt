package com.kasadefteri.domain.usecase

import com.kasadefteri.data.repository.KasaRepository
import com.kasadefteri.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.LocalTime
import javax.inject.Inject

// ─── Add Transaction ─────────────────────────────────────

class AddTransactionUseCase @Inject constructor(
    private val repository: KasaRepository
) {
    suspend operator fun invoke(transaction: Transaction): Long =
        repository.addTransaction(transaction)
}

// ─── Parse Fast Input ────────────────────────────────────
// "250 market", "2000 maaş", "90 elektrik faturası" gibi girişleri ayrıştırır

class ParseFastInputUseCase @Inject constructor() {
    operator fun invoke(input: String): ParsedInput? {
        val parts = input.trim().split("\\s+".toRegex())
        if (parts.isEmpty()) return null

        val amount = parts[0].replace(",", ".").toDoubleOrNull() ?: return null
        val rest = parts.drop(1).joinToString(" ").lowercase()

        // Kategori ve tür tespiti
        var detectedCategory = Category.DIGER
        var detectedType = TransactionType.EXPENSE

        for ((category, keywords) in Category.keywords) {
            if (keywords.any { rest.contains(it) }) {
                detectedCategory = category
                if (category == Category.MAAS) detectedType = TransactionType.INCOME
                break
            }
        }

        val description = if (rest.isBlank()) detectedCategory.label else rest.replaceFirstChar { it.uppercase() }

        return ParsedInput(
            amount = amount,
            category = detectedCategory,
            description = description,
            type = detectedType
        )
    }
}

// ─── Get Daily Summary ───────────────────────────────────

class GetDailySummaryUseCase @Inject constructor(
    private val repository: KasaRepository
) {
    operator fun invoke(date: LocalDate): Flow<DailySummary> =
        repository.getTransactionsByDate(date).map { transactions ->
            DailySummary(
                date = date,
                totalIncome = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount },
                totalExpense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount },
                transactions = transactions
            )
        }
}

// ─── Get Monthly Summary ─────────────────────────────────

class GetMonthlySummaryUseCase @Inject constructor(
    private val repository: KasaRepository
) {
    operator fun invoke(month: Int, year: Int): Flow<MonthlySummary> =
        repository.getTransactionsByMonth(month, year).map { transactions ->
            val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
            val expense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

            val categoryBreakdown = transactions
                .filter { it.type == TransactionType.EXPENSE }
                .groupBy { it.category }
                .mapValues { (_, txList) -> txList.sumOf { it.amount } }
                .toSortedMap(compareByDescending { categoryBreakdown ->
                    transactions.filter { it.type == TransactionType.EXPENSE && it.category == categoryBreakdown }
                        .sumOf { it.amount }
                })

            MonthlySummary(
                month = month,
                year = year,
                totalIncome = income,
                totalExpense = expense,
                categoryBreakdown = categoryBreakdown,
                transactionCount = transactions.size
            )
        }
}

// ─── Get Budget Progress ─────────────────────────────────

data class BudgetProgress(
    val budget: Budget,
    val spent: Double,
    val percentage: Float
) {
    val remaining: Double get() = budget.limitAmount - spent
    val isOverBudget: Boolean get() = spent > budget.limitAmount
    val isWarning: Boolean get() = percentage >= 0.8f && !isOverBudget
}

class GetBudgetProgressUseCase @Inject constructor(
    private val repository: KasaRepository
) {
    operator fun invoke(month: Int, year: Int): Flow<List<BudgetProgress>> =
        repository.getBudgetsForMonth(month, year).map { budgets ->
            budgets.map { budget ->
                val spent = repository.getCategorySpend(budget.category, month, year)
                val percentage = if (budget.limitAmount > 0) (spent / budget.limitAmount).toFloat() else 0f
                BudgetProgress(budget, spent, percentage.coerceIn(0f, 2f))
            }
        }
}

// ─── Quick Transaction from Parsed Input ─────────────────

class QuickAddTransactionUseCase @Inject constructor(
    private val parseFastInput: ParseFastInputUseCase,
    private val addTransaction: AddTransactionUseCase
) {
    suspend operator fun invoke(input: String): Boolean {
        val parsed = parseFastInput(input) ?: return false
        val transaction = Transaction(
            type = parsed.type,
            category = parsed.category,
            description = parsed.description,
            amount = parsed.amount,
            date = LocalDate.now(),
            time = LocalTime.now(),
            paymentMethod = PaymentMethod.CASH
        )
        addTransaction(transaction)
        return true
    }
}
