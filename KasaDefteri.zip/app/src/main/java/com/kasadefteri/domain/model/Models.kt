package com.kasadefteri.domain.model

import java.time.LocalDate
import java.time.LocalTime

// ─── Enums ──────────────────────────────────────────────

enum class TransactionType(val label: String) {
    INCOME("Gelir"),
    EXPENSE("Gider")
}

enum class PaymentMethod(val label: String, val emoji: String) {
    CASH("Nakit", "💵"),
    BANK("Banka", "🏦"),
    CREDIT_CARD("Kredi Kartı", "💳"),
    TRANSFER("Havale/EFT", "📲"),
    OTHER("Diğer", "🔹")
}

enum class Category(val label: String, val emoji: String) {
    MARKET("Market", "🛒"),
    FATURA("Fatura", "💡"),
    KIRA("Kira", "🏠"),
    AIDAT("Aidat", "🏢"),
    ULASIM("Ulaşım", "🚌"),
    SAGLIK("Sağlık", "💊"),
    MUTFAK("Mutfak", "🍽️"),
    TEMIZLIK("Temizlik", "🧹"),
    EV_IHTIYAC("Ev İhtiyacı", "🔧"),
    BORC("Borç/Alacak", "🤝"),
    MAAS("Maaş", "💰"),
    DIGER("Diğer", "📦");

    companion object {
        fun expenseCategories() = entries.filter { it != MAAS }
        fun incomeCategories() = listOf(MAAS, DIGER)

        // Hızlı metin ayrıştırma için anahtar kelimeler
        val keywords: Map<Category, List<String>> = mapOf(
            MARKET to listOf("market", "migros", "bim", "a101", "şok", "carrefour", "alışveriş"),
            FATURA to listOf("fatura", "elektrik", "su", "doğalgaz", "internet", "ttnet"),
            KIRA to listOf("kira"),
            AIDAT to listOf("aidat"),
            ULASIM to listOf("otobüs", "metro", "taksi", "benzin", "akbil", "istanbulkart", "ulaşım"),
            SAGLIK to listOf("eczane", "doktor", "hastane", "ilaç", "sağlık"),
            MUTFAK to listOf("ekmek", "manav", "kasap", "lokanta", "restoran"),
            MAAS to listOf("maaş", "maas", "ücret", "maaş", "gelir", "ikramiye"),
        )
    }
}

enum class RecurringFrequency(val label: String) {
    MONTHLY("Aylık"),
    WEEKLY("Haftalık"),
    YEARLY("Yıllık")
}

// ─── Domain Models ───────────────────────────────────────

data class Transaction(
    val id: Long = 0,
    val type: TransactionType,
    val category: Category,
    val description: String,
    val amount: Double,
    val date: LocalDate,
    val time: LocalTime,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val isRecurring: Boolean = false,
    val note: String? = null
)

data class RecurringPayment(
    val id: Long = 0,
    val name: String,
    val category: Category,
    val amount: Double,
    val dueDay: Int,        // Ayın kaçı
    val frequency: RecurringFrequency = RecurringFrequency.MONTHLY,
    val isActive: Boolean = true,
    val isPaid: Boolean = false,
    val paymentMethod: PaymentMethod = PaymentMethod.BANK
)

data class Budget(
    val id: Long = 0,
    val category: Category,
    val limitAmount: Double,
    val month: Int,
    val year: Int
)

data class DailySummary(
    val date: LocalDate,
    val totalIncome: Double,
    val totalExpense: Double,
    val transactions: List<Transaction>
) {
    val netBalance: Double get() = totalIncome - totalExpense
}

data class MonthlySummary(
    val month: Int,
    val year: Int,
    val totalIncome: Double,
    val totalExpense: Double,
    val categoryBreakdown: Map<Category, Double>,
    val transactionCount: Int
) {
    val netBalance: Double get() = totalIncome - totalExpense
    val savingsRate: Double get() = if (totalIncome > 0) (netBalance / totalIncome) * 100 else 0.0
}

// Hızlı giriş parse sonucu
data class ParsedInput(
    val amount: Double,
    val category: Category,
    val description: String,
    val type: TransactionType
)
